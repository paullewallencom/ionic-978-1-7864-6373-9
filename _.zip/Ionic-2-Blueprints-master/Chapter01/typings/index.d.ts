/// <reference path="globals/es6-shim/index.d.ts" />
/// <reference path="globals/firebase3/index.d.ts" />
